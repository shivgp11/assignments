create user 'cs363'@'%' identified by 'F2020';
grant all privileges on group70.* to 'cs363'@'%';
grant super on *.* to 'cs363'@'%';

create user 'cs363'@'%1' identified by 'F2021';
grant all privileges on group70.* to 'cs363'@'%1';
grant super on *.* to 'cs363'@'%1';