README:

Username(s): cs363%, cs363%1

Password for cs363%: F2020
Password for cs363%1: F2021

Run in the following order, please: ProjectDDL, EnsureDataConsistency, ProjectInsert

*Our java program uses queries from Before.sql*